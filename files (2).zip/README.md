# Sistem Peminjaman Ruang Kampus

Proyek pembelajaran Rekayasa Perangkat Lunak.

## Fitur
- Menampilkan daftar ruang
- Pengajuan peminjaman
- Pemeriksaan jadwal
- Melihat status pengajuan

## Teknologi
HTML, CSS, JavaScript (tanpa framework). Data pengajuan disimpan di browser (localStorage).

## Cara menjalankan
Buka `index.html` di browser, atau lihat versi online lewat GitHub Pages.

## Developer
Nama: Nama Mahasiswa
