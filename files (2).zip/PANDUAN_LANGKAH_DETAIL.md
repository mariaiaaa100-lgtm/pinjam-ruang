# Langkah Detail Praktik Git dan GitHub
Rekayasa Perangkat Lunak, Pertemuan 11: Sistem Peminjaman Ruang Kampus

Semua kode yang dibutuhkan sudah disediakan di folder `tahap-praktik/` (versi bertahap sesuai panduan) dan `peminjaman-ruang/` (versi final yang lebih lengkap untuk GitHub Pages).

Setiap langkah punya tanda **[Screenshot]** di tempat Anda perlu mengambil bukti untuk dokumentasi.

---

## BAGIAN 1. Persiapan

### Langkah 1. Instal tools
1. Unduh dan instal Git: https://git-scm.com/downloads (pilih Windows, klik Next sampai selesai, biarkan opsi bawaan).
2. Unduh dan instal Visual Studio Code: https://code.visualstudio.com/download
3. Buat akun GitHub di https://github.com/ (jika belum punya) dan verifikasi email.

### Langkah 2. Periksa instalasi Git
1. Buka VS Code, lalu menu **Terminal → New Terminal**.
2. Ketik:
   ```
   git --version
   ```
3. Hasil yang benar: `git version 2.xx.x`.
4. Jika muncul `git is not recognized`, tutup VS Code, buka lagi. Jika masih gagal, instal ulang Git.

**[Screenshot]** terminal yang menampilkan versi Git.

### Langkah 3. Konfigurasi identitas
```
git config --global user.name "Nama Anda"
git config --global user.email "email-akun-github@example.com"
git config --global --list
```
Pastikan `user.name` dan `user.email` muncul di daftar.

**[Screenshot]** hasil `git config --global --list`.

---

## BAGIAN 2. Membuat proyek

### Langkah 4. Buat folder proyek
1. Di File Explorer, buat folder `peminjaman-ruang` (misalnya di `Documents/RPL/`).
2. Di VS Code: **File → Open Folder** lalu pilih folder tersebut.
3. Terminal baru: **Terminal → New Terminal** (pastikan path-nya berakhir dengan `peminjaman-ruang`).

### Langkah 5. Buat index.html (versi awal)
1. Klik ikon **New File** di panel Explorer, beri nama `index.html`.
2. Salin isi dari `tahap-praktik/tahap-1_index.html`, simpan (Ctrl+S).

### Langkah 6. Buat README.md
1. New File, beri nama `README.md`.
2. Salin isi dari `tahap-praktik/README.md`. Ganti "Nama Mahasiswa" dengan nama Anda. Simpan.
3. Klik kanan `index.html` di Explorer, pilih **Reveal in File Explorer**, lalu buka di browser untuk memastikan tampil.

**[Screenshot]** VS Code dengan dua file dan tampilan `index.html` di browser.

---

## BAGIAN 3. Mengaktifkan Git

### Langkah 7. Inisialisasi repository
```
git init -b main
```
Jika Git versi lama menolak opsi `-b`:
```
git init
git branch -M main
```

### Langkah 8. Periksa status
```
git status
```
Kedua file tampil merah sebagai *untracked*.

### Langkah 9. Staging
```
git add .
git status
```
Sekarang kedua file tampil hijau (siap di-commit).

### Langkah 10. Commit pertama
```
git commit -m "chore: initial project"
git log --oneline
```
**[Screenshot]** hasil `git status` (sebelum dan sesudah add) dan `git log --oneline`.

---

## BAGIAN 4. Mengunggah ke GitHub

### Langkah 11. Buat repository di GitHub
1. Buka https://github.com/ dan login.
2. Klik **+** di pojok kanan atas, pilih **New repository**.
3. Repository name: `peminjaman-ruang`.
4. Description: `Proyek pembelajaran Rekayasa Perangkat Lunak.`
5. Visibility: pilih **Public** jika ingin membuat website lewat GitHub Pages (Pages untuk repository Private membutuhkan paket berbayar). Pilih Private jika hanya untuk praktik.
6. **Jangan** centang Add a README, .gitignore, atau license.
7. Klik **Create repository**, lalu salin URL-nya, misalnya `https://github.com/USERNAME/peminjaman-ruang.git`.

**[Screenshot]** halaman repository yang baru dibuat.

### Langkah 12. Hubungkan lokal dengan GitHub
```
git remote add origin https://github.com/USERNAME/peminjaman-ruang.git
git remote -v
```
Ganti `USERNAME` dengan username GitHub Anda. Hasil `git remote -v` harus menampilkan dua baris (fetch dan push).

### Langkah 13. Push
```
git push -u origin main
```
Jika muncul jendela login, pilih **Sign in with your browser** lalu izinkan. Refresh halaman repository, `index.html` dan `README.md` harus terlihat.

**[Screenshot]** terminal setelah push berhasil dan halaman GitHub yang sudah berisi file.

---

## BAGIAN 5. Branch dan fitur

### Langkah 14. Buat branch fitur
```
git switch -c feature/booking-form
git branch
```
Tanda `*` harus berada di `feature/booking-form`.

### Langkah 15. Tambah formulir
1. Buka `index.html`.
2. Ganti seluruh isinya dengan isi `tahap-praktik/tahap-2_index.html` (formulir muncul setelah daftar menu).
3. Simpan, lalu refresh browser untuk melihat formulir.

**[Screenshot]** kode formulir di VS Code dan tampilannya di browser.

### Langkah 16. Commit
```
git status
git add index.html
git commit -m "feat: add booking form"
```

### Langkah 17. Push branch
```
git push -u origin feature/booking-form
```
**[Screenshot]** terminal dan daftar branch di GitHub.

---

## BAGIAN 6. Pull Request, review, merge

### Langkah 18. Buat Pull Request
1. Di halaman repository, klik **Compare & pull request** (atau tab **Pull requests → New pull request**).
2. Base: `main`, compare: `feature/booking-form`.
3. Title: `Add booking form`.
4. Description:
   ```
   Menambahkan formulir pengajuan peminjaman ruang kampus.

   Perubahan:
   - Input nama mahasiswa
   - Pilihan ruang
   - Input tanggal peminjaman
   ```
5. Klik **Create pull request**.

### Langkah 19. Code review
1. Buka tab **Files changed**.
2. Periksa: baris hijau adalah tambahan, tidak ada bagian lama yang terhapus.
3. Opsional: klik tanda **+** di samping baris kode untuk menulis komentar, lalu **Review changes → Approve** (jika direview anggota lain) atau **Comment** (jika review sendiri).

**[Screenshot]** tab Files changed dan komentar/review.

### Langkah 20. Merge
1. Kembali ke tab **Conversation**, klik **Merge pull request → Confirm merge**.
2. Di terminal:
   ```
   git switch main
   git pull origin main
   git log --oneline
   ```
**[Screenshot]** halaman PR berstatus **Merged** dan hasil `git log --oneline`.

---

## BAGIAN 7. Simulasi merge conflict (opsional)

Contoh file sudah disiapkan: `konflik-developer-A.js` (`maxBooking = 5`) dan `konflik-developer-B.js` (`maxBooking = 10`).

1. Pastikan berada di `main` dan sudah bersih (`git status`).
2. Buat file `batas.js` berisi:
   ```js
   const maxBooking = 3;
   ```
   Commit di `main`:
   ```
   git add batas.js
   git commit -m "chore: add batas.js"
   ```
3. Branch A: ubah nilai jadi 5.
   ```
   git switch -c feature/batas-booking-a
   ```
   Ubah `batas.js` jadi `const maxBooking = 5;` lalu
   ```
   git add batas.js
   git commit -m "feat: batas booking 5"
   ```
4. Kembali ke `main`, buat branch B dengan nilai 10.
   ```
   git switch main
   git switch -c feature/batas-booking-b
   ```
   Ubah jadi `const maxBooking = 10;` lalu
   ```
   git add batas.js
   git commit -m "feat: batas booking 10"
   ```
5. Gabungkan A ke `main`, lalu B ke `main`:
   ```
   git switch main
   git merge feature/batas-booking-a
   git merge feature/batas-booking-b
   ```
   Merge kedua akan konflik. VS Code menampilkan tombol **Accept Current / Accept Incoming / Accept Both**.
6. Pilih nilai sesuai kebutuhan bisnis (diskusikan dulu), hapus penanda `<<<<<<<`, `=======`, `>>>>>>>`, simpan.
7. Selesaikan:
   ```
   git add batas.js
   git commit -m "fix: resolve conflict maxBooking"
   ```
**[Screenshot]** penanda konflik di VS Code dan hasil setelah diselesaikan.

---

## BAGIAN 8. Menjadikan versi final sebagai website (GitHub Pages)

Bagian ini membuat tampilan "web GitHub" dari folder `peminjaman-ruang/` (index.html, style.css, script.js, README.md).

### A. Buat branch baru untuk pembaruan website
```
git switch main
git pull origin main
git switch -c feature/website-final
```

### B. Ganti file proyek
Salin keempat file dari folder `peminjaman-ruang/` hasil unduhan ke folder proyek Anda, timpa `index.html` dan `README.md`, serta tambahkan `style.css` dan `script.js`. Ganti "Nama Mahasiswa" di README dengan nama Anda. Uji dengan membuka `index.html` di browser.

### C. Commit dan push
```
git add .
git commit -m "feat: website final peminjaman ruang"
git push -u origin feature/website-final
```
Lalu buat Pull Request (judul: `Website final peminjaman ruang`), review, dan **Merge** seperti Bagian 6. Setelah itu:
```
git switch main
git pull origin main
```

### D. Aktifkan GitHub Pages
1. Di repository GitHub, buka **Settings → Pages**.
2. Source: **Deploy from a branch**.
3. Branch: `main`, folder: `/ (root)`, lalu **Save**.
4. Tunggu 1 sampai 3 menit, refresh halaman Settings → Pages sampai muncul alamat:
   ```
   https://USERNAME.github.io/peminjaman-ruang/
   ```
5. Buka alamat tersebut. Website sudah online.

Jika halaman 404, tunggu beberapa menit dan pastikan `index.html` berada di akar repository (bukan di dalam subfolder).

**[Screenshot]** pengaturan Pages dan tampilan website online.

---

## Checklist akhir
- [ ] Git terinstal dan identitas dikonfigurasi
- [ ] Repository lokal dan commit pertama
- [ ] Repository GitHub dibuat dan `main` ter-push
- [ ] Branch `feature/booking-form` ter-commit dan ter-push
- [ ] Pull Request dibuat, direview, di-merge
- [ ] `main` lokal diperbarui (`git pull`)
- [ ] (Opsional) simulasi konflik selesai
- [ ] (Opsional) website online lewat GitHub Pages

## Kendala umum
| Pesan | Solusi |
|---|---|
| `git is not recognized` | Instal ulang Git, buka ulang VS Code |
| `Author identity unknown` | Jalankan `git config --global user.name` dan `user.email` |
| `remote origin already exists` | Cek `git remote -v`. Untuk mengganti URL: `git remote set-url origin URL_BARU` |
| `rejected (fetch first)` | Jalankan `git pull origin main` lalu push lagi |
| `Authentication failed` | Login ulang lewat browser atau Git Credential Manager |
| Merge conflict | Buka file, pilih hasil yang benar, hapus penanda, `git add`, `git commit` |
