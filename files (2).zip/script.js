// Aturan bisnis: batas maksimum pengajuan aktif per mahasiswa.
// (Nilai ini dipakai pada simulasi merge conflict di Bagian 7.)
const maxBooking = 5;

const STORAGE_KEY = "peminjaman-ruang:data";

const ROOMS = [
  { id: "r101", nama: "Ruang 101", kapasitas: 40, fasilitas: "Proyektor, AC" },
  { id: "r202", nama: "Ruang 202", kapasitas: 30, fasilitas: "Papan tulis, AC" },
  { id: "lab1", nama: "Laboratorium 1", kapasitas: 25, fasilitas: "20 komputer, AC" }
];

const SESI = [
  "08.00-10.00",
  "10.00-12.00",
  "13.00-15.00",
  "15.00-17.00"
];

const $ = (id) => document.getElementById(id);

function load() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
  } catch (e) {
    return [];
  }
}
function save(data) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (e) { /* penyimpanan tidak tersedia */ }
}

let bookings = load();

function todayISO() {
  const d = new Date();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return d.getFullYear() + "-" + m + "-" + day;
}

function formatTanggal(iso) {
  const [y, m, d] = iso.split("-");
  return d + "/" + m + "/" + y;
}

function roomName(id) {
  const r = ROOMS.find((x) => x.id === id);
  return r ? r.nama : id;
}

function isBusy(roomId, tanggal, sesi) {
  return bookings.some((b) => b.ruang === roomId && b.tanggal === tanggal && b.sesi === sesi);
}

/* ---------- Render ---------- */
function renderRooms() {
  const wrap = $("rooms");
  wrap.textContent = "";
  ROOMS.forEach((r) => {
    const card = document.createElement("div");
    card.className = "room";
    const h = document.createElement("h3");
    h.textContent = r.nama;
    const p1 = document.createElement("p");
    p1.textContent = "Kapasitas " + r.kapasitas + " orang";
    const p2 = document.createElement("p");
    p2.textContent = r.fasilitas;
    card.append(h, p1, p2);
    wrap.appendChild(card);
  });

  const sel = $("ruang-pilih");
  sel.textContent = "";
  ROOMS.forEach((r) => {
    const o = document.createElement("option");
    o.value = r.id;
    o.textContent = r.nama;
    sel.appendChild(o);
  });

  const sesi = $("sesi");
  sesi.textContent = "";
  SESI.forEach((s) => {
    const o = document.createElement("option");
    o.value = s;
    o.textContent = s;
    sesi.appendChild(o);
  });
}

function renderBoard() {
  const today = todayISO();
  $("board-title").textContent = "Jadwal hari ini, " + formatTanggal(today);
  const board = $("board");
  board.textContent = "";

  const head = document.createElement("div");
  head.className = "row head-row";
  head.appendChild(document.createElement("span"));
  SESI.forEach((s) => {
    const c = document.createElement("span");
    c.className = "cell";
    c.textContent = s.slice(0, 5);
    head.appendChild(c);
  });
  board.appendChild(head);

  ROOMS.forEach((r) => {
    const row = document.createElement("div");
    row.className = "row";
    const name = document.createElement("span");
    name.className = "rn";
    name.textContent = r.nama;
    row.appendChild(name);
    SESI.forEach((s) => {
      const busy = isBusy(r.id, today, s);
      const c = document.createElement("span");
      c.className = "cell " + (busy ? "busy" : "free");
      c.textContent = busy ? "Terpakai" : "Kosong";
      row.appendChild(c);
    });
    board.appendChild(row);
  });
}

function renderStatus() {
  const body = $("status-body");
  body.textContent = "";
  $("empty").hidden = bookings.length > 0;

  bookings.forEach((b) => {
    const tr = document.createElement("tr");
    [b.nama, roomName(b.ruang), formatTanggal(b.tanggal), b.sesi, b.keperluan].forEach((v) => {
      const td = document.createElement("td");
      td.textContent = v;
      tr.appendChild(td);
    });

    const tdStatus = document.createElement("td");
    const badge = document.createElement("span");
    badge.className = "badge";
    badge.textContent = "Diajukan";
    tdStatus.appendChild(badge);
    tr.appendChild(tdStatus);

    const tdAct = document.createElement("td");
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "link";
    btn.textContent = "Batalkan";
    btn.addEventListener("click", () => {
      bookings = bookings.filter((x) => x.id !== b.id);
      save(bookings);
      renderAll();
      setNotif("Pengajuan dibatalkan.", "ok");
    });
    tdAct.appendChild(btn);
    tr.appendChild(tdAct);
    body.appendChild(tr);
  });
}

function renderAll() {
  renderBoard();
  renderStatus();
}

/* ---------- Form ---------- */
function setNotif(msg, type) {
  const n = $("notif");
  n.textContent = msg;
  n.className = "notif " + (type || "");
}

function setErr(field, msg) {
  $("err-" + field).textContent = msg;
  $(field).setAttribute("aria-invalid", msg ? "true" : "false");
}

function validate() {
  let ok = true;
  const nama = $("nama").value.trim();
  const tanggal = $("tanggal").value;
  const keperluan = $("keperluan").value.trim();

  setErr("nama", ""); setErr("tanggal", ""); setErr("keperluan", "");

  if (!nama) { setErr("nama", "Nama mahasiswa wajib diisi."); ok = false; }
  if (!tanggal) {
    setErr("tanggal", "Pilih tanggal peminjaman."); ok = false;
  } else if (tanggal < todayISO()) {
    setErr("tanggal", "Tanggal tidak boleh sebelum hari ini."); ok = false;
  }
  if (!keperluan) { setErr("keperluan", "Tuliskan keperluan peminjaman."); ok = false; }
  return ok;
}

function onSubmit(e) {
  e.preventDefault();
  setNotif("", "");
  if (!validate()) return;

  const nama = $("nama").value.trim();
  const ruang = $("ruang-pilih").value;
  const tanggal = $("tanggal").value;
  const sesi = $("sesi").value;
  const keperluan = $("keperluan").value.trim();

  // Pemeriksaan jadwal
  if (isBusy(ruang, tanggal, sesi)) {
    setNotif(roomName(ruang) + " sudah dipinjam pada " + formatTanggal(tanggal) + " sesi " + sesi + ". Pilih sesi atau ruang lain.", "bad");
    return;
  }

  // Batas maksimum pengajuan per mahasiswa
  const aktif = bookings.filter((b) => b.nama.toLowerCase() === nama.toLowerCase()).length;
  if (aktif >= maxBooking) {
    setNotif("Batas " + maxBooking + " pengajuan aktif sudah tercapai. Batalkan salah satu pengajuan terlebih dahulu.", "bad");
    return;
  }

  bookings.push({ id: Date.now(), nama, ruang, tanggal, sesi, keperluan });
  save(bookings);
  renderAll();
  $("booking-form").reset();
  $("tanggal").min = todayISO();
  setNotif("Pengajuan " + roomName(ruang) + " pada " + formatTanggal(tanggal) + " berhasil dikirim.", "ok");
}

/* ---------- Mulai ---------- */
renderRooms();
$("tanggal").min = todayISO();
$("tanggal").value = todayISO();
$("booking-form").addEventListener("submit", onSubmit);
renderAll();
